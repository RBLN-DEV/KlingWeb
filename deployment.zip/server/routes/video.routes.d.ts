declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=video.routes.d.ts.map