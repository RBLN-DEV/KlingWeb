declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=image.routes.d.ts.map